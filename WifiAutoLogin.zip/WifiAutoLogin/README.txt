CAMPUS WI-FI AUTO-LOGIN SETUP
-----------------------------

Follow these 3 simple steps to make your laptop automatically connect and log into the PESU Wi-Fi in the background.

STEP 1: EXTRACT THE FOLDER
You must extract/unzip this folder before doing anything else. Right-click the downloaded ZIP file and select "Extract All...". 
Verification: You should now be working inside a normal folder, not a ZIP file.

STEP 2: ADD YOUR CREDENTIALS
1. Right-click the "wifi_automation.ps1" file and select "Open with" -> "Notepad".
2. Find the placeholders for your PESU username and password, and replace them with your actual login details.
3. Save and close the file.
Verification: Open the file one more time to ensure your details were saved successfully.

STEP 3: INSTALL
1. Right-click the "install.bat" file and select "Run as administrator".
2. Click "Yes" if Windows asks for permission.
3. A black window will appear, set up the files, and say "Setup Complete!".
Verification: The setup is successful if you see the "Setup Complete!" message. Press any key to close the window. The script is now active and will run silently every time you turn on your PC.

-----------------------------
HOW TO LOG OUT OR PAUSE THE SCRIPT:
If you need to log out of the Wi-Fi or stop the script from auto-connecting:
1. Right-click "logout.bat" and select "Run as administrator".
2. It will kill the background script and disconnect your Wi-Fi.
3. To turn the auto-login back on later, either restart your PC or run "install.bat" again.

HOW TO UNINSTALL (If you ever need to):
1. Open the Windows Start Menu, type "Task Scheduler", and open it.
2. Find "CampusWiFiAutoLogin" in the main list, right-click it, and select "Delete". 
3. Open File Explorer, go to your C: drive, and delete the "C:\Scripts" folder.