@echo off
echo Requesting Admin Rights...
net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

echo Stopping the Auto-Login background task...
powershell -Command "Stop-ScheduledTask -TaskName 'CampusWiFiAutoLogin' -ErrorAction SilentlyContinue"

echo Killing the active background script...
powershell -Command "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'wifi_automation.ps1' } | Invoke-CimMethod -MethodName Terminate"

echo Disconnecting from Campus Wi-Fi...
netsh wlan disconnect

echo.
echo ====================================================
echo LOGOUT SUCCESSFUL!
echo The background auto-login script has been stopped.
echo ====================================================
echo.
pause