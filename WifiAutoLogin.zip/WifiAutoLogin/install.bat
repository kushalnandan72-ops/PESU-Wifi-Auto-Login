@echo off
echo Requesting Admin Rights...
net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

echo Setting up Wi-Fi Auto-Login...
if not exist "C:\Scripts" mkdir "C:\Scripts"

copy /y "%~dp0wifi_automation.ps1" "C:\Scripts\" >nul
copy /y "%~dp0run_hidden.vbs" "C:\Scripts\" >nul

powershell -ExecutionPolicy Bypass -Command "$Action = New-ScheduledTaskAction -Execute 'wscript.exe' -Argument '\"C:\Scripts\run_hidden.vbs\"'; $Trigger = New-ScheduledTaskTrigger -AtLogOn; $Settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries; Register-ScheduledTask -TaskName 'CampusWiFiAutoLogin' -Action $Action -Trigger $Trigger -Settings $Settings -Force; Start-ScheduledTask -TaskName 'CampusWiFiAutoLogin'"

echo.
echo Setup Complete! The Wi-Fi auto-login is now running silently in the background. It will automatically connect to PESU-EC-Campus
echo It will also start automatically every time you turn on your PC.
pause