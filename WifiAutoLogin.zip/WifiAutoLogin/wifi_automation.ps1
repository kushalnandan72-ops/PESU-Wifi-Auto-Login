# 1. Check if internet is fully functional (beyond the captive portal wall)
function Test-InternetConnection {
    try {
        $request = [System.Net.WebRequest]::Create("http://www.msftconnecttest.com/connecttest.txt");
        $request.Timeout = 3000; 
        $response = $request.GetResponse();
        
        $stream = $response.GetResponseStream();
        $reader = New-Object System.IO.StreamReader($stream);
        $content = $reader.ReadToEnd();
        
        $reader.Close();
        $response.Close();
        
        if ($content -eq "Microsoft Connect Test") { return $true; }
        else { return $false; }
    } catch {
        return $false;
    }
};

# 2. Automatically submit credentials with a dynamically generated token
function Invoke-CaptivePortalLogin {
    try {
        $session = New-Object Microsoft.PowerShell.Commands.WebRequestSession;
        $loginUrl = "http://192.168.254.1:8090/login.xml"; 
        
        # Automatically generate the current millisecond timestamp for 'a'
        $dynamicToken = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds();

        $body = @{
            mode        = "191";
            username    = "PES2UG25CS271";
            password    = "kush123*";
            a           = "$dynamicToken";
            producttype = "0";
        };

        $response = Invoke-WebRequest -Uri $loginUrl -Method Post -Body $body -WebSession $session -TimeoutSec 5 -UseBasicParsing;
        Write-Host "Captive portal login packet sent successfully (Token: $dynamicToken)." -ForegroundColor Green;
        return $true;
    } catch {
        Write-Host "Auto-login failed: $_" -ForegroundColor Red;
        return $false;
    }
};

Write-Host "Starting Captive Portal Auto-Monitor..." -ForegroundColor Cyan;
Write-Host "Press Ctrl+C to stop this script." -ForegroundColor DarkGray;

# 3. Continuous background loop
while ($true) {
    # Check if the user manually toggled Wi-Fi off in Windows
    $wifiStatus = netsh wlan show interfaces;
    
    if ($wifiStatus -match "Software Off" -or $wifiStatus -match "Hardware Off") {
        # Wi-Fi is off. Skip the connection steps and just sleep until next check.
        Start-Sleep -Seconds 6;
        continue; 
    }

    # If Wi-Fi is ON, proceed with normal internet checks
    $isConnected = Test-InternetConnection;

    if (-not $isConnected) {
        $timestamp = Get-Date -Format "HH:mm:ss";
        Write-Host "[$timestamp] Connection lost or captive portal detected. Reconnecting..." -ForegroundColor Yellow;

        # Connect to Wi-Fi Network
        netsh wlan connect name="PESU-EC-Campus";

        # Wait for connection, then auto-login to the portal
        Start-Sleep -Seconds 2;
        Invoke-CaptivePortalLogin;
    };

    # Sleep before next check
    Start-Sleep -Seconds 6;
};